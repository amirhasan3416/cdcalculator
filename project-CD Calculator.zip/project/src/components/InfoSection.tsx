import React from 'react';
import { Info, TrendingUp, Lock, AlertCircle, Banknote, Clock, ArrowUpRight } from 'lucide-react';

const InfoSection: React.FC = () => {
  return (
    <div className="bg-gray-50 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-center mb-12">Understanding Certificates of Deposit</h2>
        
        <div className="grid md:grid-cols-3 gap-8 mb-12">
          <div className="bg-white p-6 rounded-xl shadow-md">
            <Lock className="h-8 w-8 text-blue-600 mb-4" />
            <h3 className="text-xl font-semibold mb-3">Secure Investment</h3>
            <p className="text-gray-600">
              CDs are time deposits that offer guaranteed returns, backed by FDIC insurance up to $250,000.
            </p>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-md">
            <TrendingUp className="h-8 w-8 text-blue-600 mb-4" />
            <h3 className="text-xl font-semibold mb-3">Higher Returns</h3>
            <p className="text-gray-600">
              Generally offer higher interest rates than traditional savings accounts, especially for longer terms.
            </p>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-md">
            <AlertCircle className="h-8 w-8 text-blue-600 mb-4" />
            <h3 className="text-xl font-semibold mb-3">Important Note</h3>
            <p className="text-gray-600">
              Early withdrawal may result in penalties. Choose your term length carefully.
            </p>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-12">
          <div className="bg-white p-8 rounded-xl shadow-md">
            <h3 className="text-2xl font-bold text-gray-800 mb-6">Types of CDs</h3>
            <div className="space-y-4">
              <div className="flex items-start">
                <Banknote className="h-6 w-6 text-blue-600 mr-3 mt-1" />
                <div>
                  <h4 className="font-semibold">Traditional CDs</h4>
                  <p className="text-gray-600">Fixed rate and term with penalties for early withdrawal</p>
                </div>
              </div>
              <div className="flex items-start">
                <ArrowUpRight className="h-6 w-6 text-blue-600 mr-3 mt-1" />
                <div>
                  <h4 className="font-semibold">Bump-up CDs</h4>
                  <p className="text-gray-600">Option to increase rate if market rates rise</p>
                </div>
              </div>
              <div className="flex items-start">
                <Clock className="h-6 w-6 text-blue-600 mr-3 mt-1" />
                <div>
                  <h4 className="font-semibold">No-penalty CDs</h4>
                  <p className="text-gray-600">Allows withdrawal without penalties but offers lower rates</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white p-8 rounded-xl shadow-md">
            <h3 className="text-2xl font-bold text-gray-800 mb-6">CD Laddering Strategy</h3>
            <p className="text-gray-600 mb-4">
              CD laddering involves buying multiple CDs with different maturity dates to:
            </p>
            <ul className="space-y-3 text-gray-600">
              <li className="flex items-start">
                <span className="h-6 w-6 flex items-center justify-center bg-blue-100 text-blue-600 rounded-full mr-3 flex-shrink-0">1</span>
                <span>Take advantage of higher long-term rates</span>
              </li>
              <li className="flex items-start">
                <span className="h-6 w-6 flex items-center justify-center bg-blue-100 text-blue-600 rounded-full mr-3 flex-shrink-0">2</span>
                <span>Maintain regular access to your money</span>
              </li>
              <li className="flex items-start">
                <span className="h-6 w-6 flex items-center justify-center bg-blue-100 text-blue-600 rounded-full mr-3 flex-shrink-0">3</span>
                <span>Minimize interest rate risk</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="bg-white p-8 rounded-xl shadow-md">
          <div className="flex items-start mb-6">
            <Info className="h-6 w-6 text-blue-600 mr-3 mt-1" />
            <div>
              <h3 className="text-xl font-semibold mb-2">How CDs Work</h3>
              <p className="text-gray-600 mb-4">
                When you open a CD, you agree to leave your money deposited for a specific term in exchange for a guaranteed interest rate. 
                The bank pays you interest regularly, and at the end of the term, you receive your original deposit plus all accumulated interest.
              </p>
              <div className="bg-blue-50 p-4 rounded-lg">
                <h4 className="font-semibold text-blue-800 mb-2">Pro Tips:</h4>
                <ul className="space-y-2 text-blue-700">
                  <li>• Compare rates from multiple banks before investing</li>
                  <li>• Consider inflation rates when choosing terms</li>
                  <li>• Keep track of maturity dates to avoid automatic renewals</li>
                  <li>• Understand early withdrawal penalties before committing</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InfoSection;