import React from 'react';
import { Wallet } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-center mb-8">
          <Wallet className="h-12 w-12 mr-4" />
          <h1 className="text-4xl font-bold">CD Calculator</h1>
        </div>
        <p className="text-center text-xl text-blue-100 max-w-3xl mx-auto">
          Plan your financial future with our Certificate of Deposit calculator. 
          Make informed decisions about your investments and watch your money grow.
        </p>
      </div>
    </header>
  );
};

export default Header;