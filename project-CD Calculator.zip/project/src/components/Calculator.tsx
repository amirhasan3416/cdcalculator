import React, { useState } from 'react';
import { Calculator as CalculatorIcon, DollarSign, Percent, Calendar, ArrowRight } from 'lucide-react';

interface CalculatorResult {
  maturityAmount: number;
  totalInterest: number;
  regularSavingsComparison: number;
  monthlyInterest: number;
  effectiveRate: number;
}

const Calculator: React.FC = () => {
  const [principal, setPrincipal] = useState<number>(10000);
  const [rate, setRate] = useState<number>(4.5);
  const [term, setTerm] = useState<number>(12);
  const [compoundingFrequency, setCompoundingFrequency] = useState<number>(12);
  const [results, setResults] = useState<CalculatorResult | null>(null);

  const calculateCD = () => {
    const r = rate / 100;
    const n = compoundingFrequency;
    const t = term / 12;
    const maturityAmount = principal * Math.pow(1 + r/n, n * t);
    const totalInterest = maturityAmount - principal;
    const regularSavingsComparison = principal * (r * t);
    const monthlyInterest = totalInterest / term;
    const effectiveRate = (Math.pow(1 + r/n, n) - 1) * 100;

    setResults({
      maturityAmount,
      totalInterest,
      regularSavingsComparison,
      monthlyInterest,
      effectiveRate
    });
  };

  return (
    <div className="w-full max-w-4xl mx-auto">
      <div className="bg-white p-8 rounded-xl shadow-lg mb-8">
        <div className="grid md:grid-cols-2 gap-8">
          <div className="space-y-6">
            <div className="flex items-center space-x-3">
              <CalculatorIcon className="h-6 w-6 text-blue-600" />
              <h3 className="text-2xl font-bold text-gray-800">Calculate Your Returns</h3>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Principal Amount
                </label>
                <div className="relative">
                  <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                  <input
                    type="number"
                    value={principal}
                    onChange={(e) => setPrincipal(Number(e.target.value))}
                    className="pl-10 w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    min="0"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Annual Interest Rate (APY)
                </label>
                <div className="relative">
                  <Percent className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                  <input
                    type="number"
                    value={rate}
                    onChange={(e) => setRate(Number(e.target.value))}
                    step="0.1"
                    className="pl-10 w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    min="0"
                    max="100"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Term (months)
                </label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                  <input
                    type="number"
                    value={term}
                    onChange={(e) => setTerm(Number(e.target.value))}
                    className="pl-10 w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    min="1"
                    max="120"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Compounding Frequency
                </label>
                <select
                  value={compoundingFrequency}
                  onChange={(e) => setCompoundingFrequency(Number(e.target.value))}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value={1}>Annually</option>
                  <option value={2}>Semi-annually</option>
                  <option value={4}>Quarterly</option>
                  <option value={12}>Monthly</option>
                  <option value={365}>Daily</option>
                </select>
              </div>

              <button
                onClick={calculateCD}
                className="w-full bg-blue-600 text-white py-3 px-6 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center space-x-2"
              >
                <span>Calculate Returns</span>
                <ArrowRight className="h-5 w-5" />
              </button>
            </div>
          </div>

          <div className="bg-gray-50 p-6 rounded-xl">
            <h3 className="text-2xl font-bold text-gray-800 mb-6">Your Investment Summary</h3>
            {results ? (
              <div className="space-y-4">
                <div className="p-4 bg-white rounded-lg shadow-md border-l-4 border-green-500">
                  <p className="text-sm text-gray-600">Final Balance at Maturity</p>
                  <p className="text-3xl font-bold text-green-600">
                    ${results.maturityAmount.toFixed(2)}
                  </p>
                  <p className="text-sm text-gray-500 mt-1">
                    Initial Investment: ${principal.toFixed(2)}
                  </p>
                </div>
                
                <div className="p-4 bg-white rounded-lg shadow-md border-l-4 border-blue-500">
                  <p className="text-sm text-gray-600">Total Interest Earned</p>
                  <p className="text-2xl font-bold text-blue-600">
                    ${results.totalInterest.toFixed(2)}
                  </p>
                  <p className="text-sm text-gray-500 mt-1">
                    Monthly Interest: ${results.monthlyInterest.toFixed(2)}
                  </p>
                </div>

                <div className="p-4 bg-white rounded-lg shadow-md border-l-4 border-purple-500">
                  <p className="text-sm text-gray-600">Effective Annual Rate</p>
                  <p className="text-2xl font-bold text-purple-600">
                    {results.effectiveRate.toFixed(2)}%
                  </p>
                  <p className="text-sm text-gray-500 mt-1">
                    With {compoundingFrequency === 1 ? 'annual' : 
                          compoundingFrequency === 2 ? 'semi-annual' :
                          compoundingFrequency === 4 ? 'quarterly' :
                          compoundingFrequency === 12 ? 'monthly' : 'daily'} compounding
                  </p>
                </div>

                <div className="mt-4 p-4 bg-gray-100 rounded-lg">
                  <p className="text-sm font-medium text-gray-700">
                    Regular Savings Comparison
                  </p>
                  <p className="text-lg text-gray-600 mt-1">
                    A regular savings account would earn: ${results.regularSavingsComparison.toFixed(2)}
                  </p>
                  <p className="text-sm text-gray-500 mt-1">
                    Your CD earns ${(results.totalInterest - results.regularSavingsComparison).toFixed(2)} more!
                  </p>
                </div>
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">
                <CalculatorIcon className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                <p>Enter your investment details and click Calculate to see your returns</p>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="bg-white p-6 rounded-xl shadow-lg">
        <h3 className="text-xl font-bold text-gray-800 mb-4">Understanding Your CD Investment</h3>
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <h4 className="font-semibold text-gray-700 mb-2">Key Terms</h4>
            <ul className="space-y-2 text-gray-600">
              <li><span className="font-medium">Principal:</span> Your initial investment amount</li>
              <li><span className="font-medium">APY:</span> Annual Percentage Yield, your yearly return rate</li>
              <li><span className="font-medium">Term:</span> How long your money is invested</li>
              <li><span className="font-medium">Compounding:</span> How often interest is calculated and added</li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold text-gray-700 mb-2">Important Notes</h4>
            <ul className="space-y-2 text-gray-600">
              <li>Early withdrawal may result in penalties</li>
              <li>Interest rates are typically fixed for the entire term</li>
              <li>Longer terms usually offer higher rates</li>
              <li>FDIC insured up to $250,000 per depositor</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Calculator;