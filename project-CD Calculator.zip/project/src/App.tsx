import React from 'react';
import Header from './components/Header';
import Calculator from './components/Calculator';
import InfoSection from './components/InfoSection';

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Calculator />
        </div>
      </main>

      <InfoSection />
      
      <footer className="bg-gray-800 text-white py-8 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-gray-300">
            © {new Date().getFullYear()} CD Calculator. All calculations are estimates.
            Please consult with a financial advisor for personalized advice.
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;